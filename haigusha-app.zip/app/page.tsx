// app/page.tsx - 再構成された配偶者居住権計算アプリ（結果表示強化）
'use client';

import { useState } from 'react';
import { calculateResults } from '../utils';

export default function Home() {
  const [form, setForm] = useState({
    inheritanceDate: '',
    divisionDate: '',
    constructionDate: '',
    structure: '',
    buildingValue: 0,
    buildingArea: 0,
    rentalArea: 0,
    rentalRatio: 0, // 賃貸入居率
    landArea: 0,
    roadPrice: 0,
    landCorrection: 0,
    leaseRatio: 0,
    spouseBirthday: '',
    spouseGender: 'female',
    legalRate: 3,
  });

  const [results, setResults] = useState<any>(null);

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleCalculate = () => {
    const result = calculateResults(form);
    setResults(result);
  };

  return (
    <main className="min-h-screen p-8 max-w-5xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">配偶者居住権評価計算アプリ</h1>

      <div className="grid md:grid-cols-2 gap-6 bg-white p-6 rounded shadow">
        <h2 className="col-span-2 text-lg font-semibold">基本情報</h2>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">相続開始日（被相続人の死亡日）</label>
          <input type="date" name="inheritanceDate" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">遺産分割日（評価時点）</label>
          <input type="date" name="divisionDate" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>

        <h2 className="col-span-2 text-lg font-semibold">建物情報</h2>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">建物構造</label>
          <select name="structure" onChange={handleChange} className="border p-2 rounded w-full">
            <option value="">建物構造を選択</option>
            <option value="鉄骨鉄筋コンクリート造又は鉄筋コンクリート造">鉄骨鉄筋コンクリート造又は鉄筋コンクリート造</option>
            <option value="鉄筋コンクリート造">鉄筋コンクリート造</option>
            <option value="鉄骨鉄筋コンクリート造">鉄骨鉄筋コンクリート造</option>
            <option value="れんが作り、石造またはブロック造">れんが作り、石造またはブロック造</option>
            <option value="コンクリートブロック造">コンクリートブロック造</option>
            <option value="金属造（骨格材の肉厚4mm超)">金属造（骨格材の肉厚4mm超)</option>
            <option value="鉄骨造（重量鉄骨）">鉄骨造（重量鉄骨）</option>
            <option value="金属造（骨格材の肉厚3mm超～4mm以下)">金属造（骨格材の肉厚3mm超～4mm以下)</option>
            <option value="鉄骨造">鉄骨造</option>
            <option value="金属造（骨格材の肉厚3mm以下)">金属造（骨格材の肉厚3mm以下)</option>
            <option value="鉄骨造（軽量鉄骨）">鉄骨造（軽量鉄骨）</option>
            <option value="木造又は合成樹脂造">木造又は合成樹脂造</option>
            <option value="木造">木造</option>
            <option value="木造（軸組工法）">木造（軸組工法）</option>
            <option value="木造（枠組壁工法）">木造（枠組壁工法）</option>
            <option value="木造（プレハブ）">木造（プレハブ）</option>
            <option value="木造（ツーバイフォー）">木造（ツーバイフォー）</option>
            <option value="木造（在来工法）">木造（在来工法）</option>
            <option value="木骨モルタル造">木骨モルタル造</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">新築年月日</label>
          <input type="date" name="constructionDate" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">建物固定資産税評価額 (円)</label>
          <input type="number" name="buildingValue" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">建物延床面積 (㎡)</label>
          <input type="number" name="buildingArea" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">賃貸部分面積 (㎡)</label>
          <input type="number" name="rentalArea" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">賃貸入居率 (%) <span className="text-sm text-gray-500">※相続開始日時点</span></label>
          <input type="number" name="rentalRatio" onChange={handleChange} min="0" max="100" step="0.1" className="border p-2 rounded w-full" />
        </div>

        <h2 className="col-span-2 text-lg font-semibold">土地情報</h2>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">土地面積 (㎡)</label>
          <input type="number" name="landArea" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">路線価 (円/㎡)</label>
          <input type="number" name="roadPrice" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">土地補正率 (%)</label>
          <input type="number" name="landCorrection" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">借地権割合 (%)</label>
          <input type="number" name="leaseRatio" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>

        <h2 className="col-span-2 text-lg font-semibold">配偶者情報</h2>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">生年月日</label>
          <input type="date" name="spouseBirthday" onChange={handleChange} className="border p-2 rounded w-full" />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">性別</label>
          <select name="spouseGender" onChange={handleChange} className="border p-2 rounded w-full">
            <option value="female">女性</option>
            <option value="male">男性</option>
          </select>
        </div>
      </div>

      <div className="text-center">
        <button onClick={handleCalculate} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded">
          計算する
        </button>
      </div>

      {results && (
        <div className="bg-gray-100 p-6 mt-6 rounded shadow space-y-4">
          <h2 className="text-xl font-bold mb-4">計算結果</h2>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded shadow">
              <h3 className="font-semibold text-lg mb-2">配偶者居住権の評価</h3>
              <p>建物：{(results.buildingRight || 0).toLocaleString()} 円</p>
              <p>敷地利用権：{(results.landUse || 0).toLocaleString()} 円</p>
              <p className="font-semibold mt-2">配偶者居住権合計：{(results.spouseRightTotal || 0).toLocaleString()} 円</p>
            </div>

            <div className="bg-white p-4 rounded shadow">
              <h3 className="font-semibold text-lg mb-2">残余資産の評価</h3>
              <p>設定建物：{(results.settingBuilding || 0).toLocaleString()} 円</p>
              <p>設定敷地（所有権）：{(results.landOwner || 0).toLocaleString()} 円</p>
              <p className="font-semibold mt-2">残余資産合計：{(results.remainingAssetsTotal || 0).toLocaleString()} 円</p>
            </div>

            <div className="bg-white p-4 rounded shadow col-span-2">
              <h3 className="font-semibold text-lg mb-2">中間計算情報</h3>
              <p>配偶者年齢：{results.spouseAge || 0} 歳（満年齢）</p>
              <p>平均余命：{results.life || 0} 年</p>
              <p>複利原価率：{results.pvf || 0}</p>
              <p>経過年数：{results.elapsedYears || 0} 年</p>
              <p>耐用年数：{results.usefulLife || 0} 年</p>
              <p>居住面積：{(results.residentialArea || 0).toLocaleString()} ㎡</p>
              <p>居住面積割合：{((results.residentialRatio || 0) * 100).toFixed(2)}%</p>
              <p>賃貸面積割合：{((results.rentalAreaRatio || 0) * 100).toFixed(2)}%</p>
              <p>賃貸入居率：{((results.rentalRatio || 0) * 100).toFixed(2)}%</p>
              <p>建物評価額：{(results.buildingTaxValue || 0).toLocaleString()} 円</p>
              <p>土地評価額：{(results.landValue || 0).toLocaleString()} 円</p>
              {results.landReduction > 0 && (
                <p>土地評価減額：{(results.landReduction || 0).toLocaleString()} 円</p>
              )}
            </div>
          </div>

          <div className="text-right font-semibold text-lg">総合計：{(results.total || 0).toLocaleString()} 円</div>
        </div>
      )}
    </main>
  );
}
