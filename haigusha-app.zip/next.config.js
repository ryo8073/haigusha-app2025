/** @type {import('next').NextConfig} */
const nextConfig = {
  // Remove the experimental.appDir option as it's no longer needed
};

module.exports = nextConfig;
