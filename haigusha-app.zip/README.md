# Haigusha Residence Rights Calculator

Next.js app to compute 配偶者居住権 (Spousal Residential Rights) in Japanese inheritance cases.
